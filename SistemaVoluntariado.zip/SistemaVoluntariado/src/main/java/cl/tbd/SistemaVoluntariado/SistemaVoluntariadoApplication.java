package cl.tbd.SistemaVoluntariado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaVoluntariadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaVoluntariadoApplication.class, args);
	}

}
