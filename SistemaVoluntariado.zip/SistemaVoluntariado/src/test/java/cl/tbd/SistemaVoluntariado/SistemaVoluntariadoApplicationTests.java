package cl.tbd.SistemaVoluntariado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaVoluntariadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
